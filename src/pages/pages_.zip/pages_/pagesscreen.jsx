import React, { useRef, useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Animated,
  Dimensions,
  StatusBar,
  Image,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import AppDetails from '../../helpers/appdetails';
import { useAuth } from '../../AuthContext';

const { width: SCREEN_W } = Dimensions.get('window');

// ─── Brand Tokens ─────────────────────────────────────────────────────────────
const BRAND  = '#0C3F44';
const ACCENT = '#13C296';
const CREAM  = '#F5F0E8';
const DARK   = '#0D1B1E';
const MUTED  = '#7A9198';

const BASE_URL = 'https://hafrik.com';

// ─── API helper ───────────────────────────────────────────────────────────────
const apiFetch = async (path, token) => {
  try {
    // Normalise path: strip leading domain duplicates if present
    const clean = path.replace(/^\/?(hafrik\.com)/, '');
    const url   = `${BASE_URL}${clean.startsWith('/') ? clean : '/' + clean}`;
    const res   = await fetch(url, {
      headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    });
    return await res.json();
  } catch (e) {
    console.log(`[apiFetch] ${path}`, e?.message);
    return null;
  }
};

// ─── Extract count from various API response shapes ───────────────────────────
const extractCount = (res) =>
  res?.data?.total   ??
  res?.total         ??
  res?.data?.count   ??
  res?.count         ??
  (Array.isArray(res?.data?.data) ? res.data.data.length : null) ??
  (Array.isArray(res?.data)       ? res.data.length       : null);

// ─── Decode HTML entities (titles come with &rsquo; &mdash; etc.) ────────────
const decodeHtml = (text = '') =>
  String(text)
    .replace(/&rsquo;/g, "'").replace(/&lsquo;/g, "'")
    .replace(/&rdquo;/g, '"').replace(/&ldquo;/g, '"')
    .replace(/&mdash;/g, '—').replace(/&ndash;/g, '–')
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>').replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'").replace(/&nbsp;/g, ' ')
    .replace(/<[^>]*>/g, '')
    .replace(/\s+/g, ' ').trim();

// ─── Check if image URL is real (not a placeholder) ──────────────────────────
const isRealImage = (url) =>
  !!url &&
  !String(url).includes('blank_profile') &&
  !String(url).includes('default-article') &&
  !String(url).includes('/default.');

// ─── Extract list — handles { data: { data:[] } } AND { data: [] } ───────────
const extractList = (res) => {
  if (Array.isArray(res?.data?.data)) return res.data.data;
  if (Array.isArray(res?.data))       return res.data;
  if (Array.isArray(res?.results))    return res.results;
  return [];
};

// ─── Category config ─────────────────────────────────────────────────────────
const BASE_CATEGORIES = [
  { key: 'communities', label: 'Communities',  emoji: '👥', bg: ['#0C3F44', '#0a5a62'], route: 'Communities',  apiKey: 'communities', unit: 'groups'    },
  { key: 'businesses',  label: 'Businesses',   emoji: '💼', bg: ['#b85c1a', '#d4722a'], route: 'BusinessList', apiKey: 'businesses',  unit: 'listings'  },
  { key: 'marketplace', label: 'Marketplace',  emoji: '🛒', bg: ['#1a4a7a', '#245fa0'], route: 'Marketplace',  apiKey: 'marketplace', unit: 'items'     },
  { key: 'events',      label: 'Events',       emoji: '🎉', bg: ['#6b2fa0', '#8a3fc5'], route: 'Events',       apiKey: 'events',      unit: 'upcoming'  },
  { key: 'guides',      label: 'Guides & Tips', emoji: '📖', bg: ['#1a6b3a', '#228b4a'], route: 'Guides',      apiKey: 'articles',    unit: 'articles'  },
  { key: 'shipping',    label: 'Shipping',     emoji: '🚢', bg: ['#7a2020', '#a02a2a'], route: 'Shipping',     apiKey: null,          unit: ''          },
];

// ─── Skeleton pulse ───────────────────────────────────────────────────────────
const Skeleton = ({ width, height, radius = 10, style }) => {
  const anim = useRef(new Animated.Value(0.35)).current;
  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(anim, { toValue: 1,    duration: 800, useNativeDriver: true }),
        Animated.timing(anim, { toValue: 0.35, duration: 800, useNativeDriver: true }),
      ])
    ).start();
  }, []);
  return (
    <Animated.View
      style={[{ width, height, borderRadius: radius, backgroundColor: 'rgba(12,63,68,0.10)', opacity: anim }, style]}
    />
  );
};

// ─── Fade-in wrapper ──────────────────────────────────────────────────────────
const FadeIn = ({ delay = 0, children, style }) => {
  const opacity    = useRef(new Animated.Value(0)).current;
  const translateY = useRef(new Animated.Value(18)).current;
  useEffect(() => {
    Animated.parallel([
      Animated.timing(opacity,    { toValue: 1, duration: 480, delay, useNativeDriver: true }),
      Animated.timing(translateY, { toValue: 0, duration: 480, delay, useNativeDriver: true }),
    ]).start();
  }, []);
  return <Animated.View style={[{ opacity, transform: [{ translateY }] }, style]}>{children}</Animated.View>;
};

// ─── Section header ───────────────────────────────────────────────────────────
const SectionHeader = ({ title, onSeeAll }) => (
  <View style={styles.sectionHeader}>
    <Text style={styles.sectionTitle}>{title}</Text>
    {onSeeAll && (
      <TouchableOpacity onPress={onSeeAll} activeOpacity={0.75}>
        <Text style={styles.seeAll}>See all</Text>
      </TouchableOpacity>
    )}
  </View>
);

// ─── Category Card ────────────────────────────────────────────────────────────
const CategoryCard = ({ item, onPress }) => (
  <TouchableOpacity activeOpacity={0.82} onPress={onPress} style={[styles.catCard, { backgroundColor: item.bg[0] }]}>
    <View style={[styles.catCircle, { backgroundColor: item.bg[1] }]} />
    <Text style={styles.catEmoji}>{item.emoji}</Text>
    <Text style={styles.catLabel}>{item.label}</Text>
    {item.subtitle !== undefined ? (
      <Text style={styles.catSub}>{item.subtitle ?? '—'}</Text>
    ) : (
      <Skeleton width={64} height={11} radius={5} style={{ marginTop: 4 }} />
    )}
  </TouchableOpacity>
);

// ─── Ad Banner ────────────────────────────────────────────────────────────────
const AdBanner = ({ ad }) => {
  if (!ad) return null;
  const image = ad.image ?? ad.banner ?? ad.photo;
  return (
    <TouchableOpacity style={styles.adBanner} activeOpacity={0.88}>
      {image ? (
        <Image source={{ uri: image }} style={StyleSheet.absoluteFill} resizeMode="cover" />
      ) : null}
      <View style={styles.adOverlay}>
        <View style={styles.adPill}><Text style={styles.adPillText}>Ad</Text></View>
        {!!ad.title && <Text style={styles.adTitle} numberOfLines={1}>{ad.title}</Text>}
      </View>
    </TouchableOpacity>
  );
};

// ─── People You May Know Card ─────────────────────────────────────────────────
// Matches real API shape: { id, username, image, link, gender, verified }
const PersonCard = ({ person }) => {
  const navigation = useNavigation();

  // Use the profile link to open in-app or browser
  const handlePress = () => {
    // Navigate to in-app profile if route exists, fallback to link
    navigation.navigate('UserProfile', { userId: person.id, username: person.username });
  };

  // Detect default/blank avatar images
  const isDefaultAvatar = !person.image || String(person.image).includes('blank_profile');
  // Pick gender-appropriate fallback emoji
  const fallbackEmoji = person.gender === 2 ? '👩' : '👨';

  return (
    <TouchableOpacity style={styles.personCard} activeOpacity={0.85} onPress={handlePress}>
      {!isDefaultAvatar ? (
        <Image source={{ uri: person.image }} style={styles.personAvatar} />
      ) : (
        <View style={[styles.personAvatar, styles.personAvatarFallback]}>
          <Text style={{ fontSize: 30 }}>{fallbackEmoji}</Text>
        </View>
      )}

      {/* Verified badge */}
      {person.verified && (
        <View style={styles.verifiedBadge}>
          <Ionicons name="checkmark" size={9} color="#fff" />
        </View>
      )}

      <Text style={styles.personName} numberOfLines={1}>{person.username}</Text>

      <TouchableOpacity style={styles.connectBtn} activeOpacity={0.85}>
        <Text style={styles.connectBtnText}>Connect</Text>
      </TouchableOpacity>
    </TouchableOpacity>
  );
};

// ─── Trending Group Card ──────────────────────────────────────────────────────
const TrendingCard = ({ group, onJoin }) => {
  const members     = group.members_count ?? group.members ?? 0;
  const membersDisp = members >= 1000 ? `${(members / 1000).toFixed(1)}k` : String(members);
  const name        = decodeHtml(group.name ?? group.title ?? '');
  const about       = decodeHtml(group.about ?? group.description ?? '');
  const avatar      = group.avatar ?? group.image;

  return (
    <View style={styles.trendCard}>
      <View style={styles.trendHeader}>
        {avatar ? (
          <Image source={{ uri: avatar }} style={styles.trendAvatar} />
        ) : (
          <View style={[styles.trendAvatar, styles.trendAvatarFallback]}>
            <Text style={{ fontSize: 26 }}>👥</Text>
          </View>
        )}
        <View style={{ flex: 1 }}>
          <Text style={styles.trendName} numberOfLines={1}>{name}</Text>
          <Text style={styles.trendMeta}>{membersDisp} members · Very Active</Text>
        </View>
      </View>

      <View style={styles.trendExpanded}>
        {!!group.location && <Text style={styles.trendLocation}>📍 {group.location}</Text>}
        {!!about && <Text style={styles.trendAbout} numberOfLines={3}>{about}</Text>}

        <View style={styles.trendStats}>
          <View style={styles.trendStat}>
            <Text style={styles.trendStatNum}>{membersDisp}</Text>
            <Text style={styles.trendStatLabel}>members</Text>
          </View>
          {!!group.weekly_joins && (
            <View style={styles.trendStat}>
              <Text style={styles.trendStatNum}>+{group.weekly_joins}</Text>
              <Text style={styles.trendStatLabel}>this week</Text>
            </View>
          )}
          {!!group.activity && (
            <View style={styles.trendStat}>
              <Text style={styles.trendStatNum}>{group.activity}</Text>
              <Text style={styles.trendStatLabel}>active</Text>
            </View>
          )}
        </View>

        <TouchableOpacity style={styles.joinBtn} onPress={() => onJoin(group)} activeOpacity={0.85}>
          <Text style={styles.joinBtnText}>+ Join Group</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

// ─── Article Card ─────────────────────────────────────────────────────────────
const ArticleCard = ({ article, onPress }) => {
  // Real API shape: { id, title, snippet, image, link, category, tags }
  // title and snippet contain HTML entities — decode them
  const image  = article.image ?? article.thumbnail ?? article.photo;
  const title  = decodeHtml(article.title ?? '');
  const tag    = article.tags ? decodeHtml(article.tags.split(',')[0]) : '';
  const showImage = isRealImage(image);

  return (
    <TouchableOpacity style={styles.articleCard} activeOpacity={0.85} onPress={onPress}>
      {showImage ? (
        <Image
          source={{ uri: image }}
          style={styles.articleImg}
          resizeMode="cover"
          onError={() => {/* silently fallback */}}
        />
      ) : (
        <View style={[styles.articleImg, styles.articleImgFallback]}>
          <Text style={{ fontSize: 28 }}>📖</Text>
        </View>
      )}
      <View style={styles.articleBody}>
        {!!tag && (
          <View style={styles.articleTag}>
            <Text style={styles.articleTagText} numberOfLines={1}>{tag}</Text>
          </View>
        )}
        <Text style={styles.articleTitle} numberOfLines={2}>{title}</Text>
        <Text style={styles.articleMeta} numberOfLines={1}>{decodeHtml(article.snippet ?? '').slice(0, 60)}…</Text>
      </View>
    </TouchableOpacity>
  );
};

// ─── Autocomplete Dropdown ────────────────────────────────────────────────────
const AutocompleteDropdown = ({ results, onSelect }) => {
  if (!results.length) return null;
  return (
    <View style={styles.autocompleteWrap}>
      {results.slice(0, 6).map((r, i) => (
        <TouchableOpacity
          key={i}
          style={[styles.autocompleteItem, i < results.length - 1 && styles.autocompleteDivider]}
          onPress={() => onSelect(r)}
          activeOpacity={0.8}
        >
          <Ionicons name="search-outline" size={14} color={MUTED} style={{ marginRight: 8 }} />
          <Text style={styles.autocompleteText} numberOfLines={1}>
            {r.title ?? r.name ?? r.query ?? String(r)}
          </Text>
        </TouchableOpacity>
      ))}
    </View>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// MAIN SCREEN
// ─────────────────────────────────────────────────────────────────────────────
const DiscoveryScreen = () => {
  const navigation = useNavigation();
  const { top }    = useSafeAreaInsets();
  const { token }  = useAuth();

  // ── State ──────────────────────────────────────────────────────────────────
  const [counts, setCounts]             = useState({});           // { communities, businesses, marketplace, events, articles }
  const [ads, setAds]                   = useState([]);
  const [featuredUsers, setFeatured]    = useState([]);
  const [trendingGroups, setTrending]   = useState([]);
  const [articles, setArticles]         = useState([]);
  const [loading, setLoading]           = useState(true);

  const [search, setSearch]             = useState('');
  const [autocomplete, setAutocomplete] = useState([]);
  const [showAuto, setShowAuto]         = useState(false);
  const searchTimeout                   = useRef(null);

  const scrollY = useRef(new Animated.Value(0)).current;

  // ── Load everything in parallel ────────────────────────────────────────────
  const loadAll = useCallback(async () => {
    setLoading(true);
    const [commR, bizR, mktR, evtR, artR, adsR, usersR] = await Promise.allSettled([
      apiFetch('/api/v1/communities/list.php',             token),
      apiFetch('/api/v1/business/list.php',                token),
      apiFetch('/api/v1/marketplace/get_marketplace.php',  token),
      apiFetch('/api/v1/events/list.php',                  token),
      apiFetch('/api/v1/articles/list.php',                token),
      apiFetch('/api/v1/ads/list.php',                     token),
      apiFetch('/api/v1/people/list.php',                   token),
    ]);

    const val = (r) => (r.status === 'fulfilled' ? r.value : null);

    // counts
    setCounts({
      communities: extractCount(val(commR)),
      businesses:  extractCount(val(bizR)),
      marketplace: extractCount(val(mktR)),
      events:      extractCount(val(evtR)),
      articles:    extractCount(val(artR)),
    });

    // trending groups — top 3 communities
    const groups = extractList(val(commR));
    setTrending(Array.isArray(groups) ? groups.slice(0, 3) : []);

    // articles
    const arts = extractList(val(artR));
    setArticles(Array.isArray(arts) ? arts.slice(0, 6) : []);

    // ads
    const adList = extractList(val(adsR));
    setAds(Array.isArray(adList) ? adList : []);

    // featured users
    const users = extractList(val(usersR));
    setFeatured(Array.isArray(users) ? users : []);

    setLoading(false);
  }, [token]);

  useEffect(() => { loadAll(); }, [loadAll]);

  // ── Categories with live counts injected ───────────────────────────────────
  const categories = BASE_CATEGORIES.map((cat) => {
    if (!cat.apiKey) return { ...cat, subtitle: undefined };          // shipping: no count
    const raw = counts[cat.apiKey];
    if (raw === null || raw === undefined) return { ...cat, subtitle: undefined }; // still loading
    const display = raw >= 1000 ? `${(raw / 1000).toFixed(1)}k` : raw;
    return { ...cat, subtitle: `${display} ${cat.unit}` };
  });

  // ── Search autocomplete ────────────────────────────────────────────────────
  const handleSearchChange = (text) => {
    setSearch(text);
    if (searchTimeout.current) clearTimeout(searchTimeout.current);
    if (text.trim().length < 2) { setAutocomplete([]); setShowAuto(false); return; }
    searchTimeout.current = setTimeout(async () => {
      const res = await apiFetch(`/api/v1/search/autocomplete.php?q=${encodeURIComponent(text)}`, token);
      const items = res?.data ?? res?.results ?? [];
      setAutocomplete(Array.isArray(items) ? items : []);
      setShowAuto(true);
    }, 320);
  };

  const handleSearch = () => {
    if (!search.trim()) return;
    setShowAuto(false);
    navigation.navigate('SearchResults', { query: search });
  };

  const handleAutoSelect = (item) => {
    const q = item.title ?? item.name ?? item.query ?? '';
    setSearch(q);
    setShowAuto(false);
    navigation.navigate('SearchResults', { query: q });
  };

  // ── Animated header opacity ────────────────────────────────────────────────
  const headerOpacity = scrollY.interpolate({ inputRange: [0, 80], outputRange: [0, 1], extrapolate: 'clamp' });

  // ── Render ─────────────────────────────────────────────────────────────────
  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" />

      {/* Floating header */}
      <Animated.View style={[styles.stickyHeader, { paddingTop: top + 10, opacity: headerOpacity }]}>
        <Text style={styles.stickyTitle}>Discover</Text>
      </Animated.View>

      <Animated.ScrollView
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
        scrollEventThrottle={16}
      >
        {/* ── Hero ── */}
        <View style={[styles.hero, { paddingTop: top + 50 }]}>
          <View style={styles.blob1} />
          <View style={styles.blob2} />
          <View style={styles.blob3} />

          <FadeIn delay={0}>
            <Text style={styles.heroEyebrow}>DISCOVER</Text>
            <Text style={styles.heroHeadline}>Your diaspora.{'\n'}Your community.</Text>
          </FadeIn>

          <FadeIn delay={100} style={{ marginTop: 24, zIndex: 20 }}>
            <View style={styles.searchBar}>
              <Ionicons name="search" size={17} color="rgba(255,255,255,0.55)" style={{ marginRight: 10 }} />
              <TextInput
                style={styles.searchInput}
                placeholder="Search people, groups, cities…"
                placeholderTextColor="rgba(255,255,255,0.4)"
                value={search}
                onChangeText={handleSearchChange}
                onSubmitEditing={handleSearch}
                returnKeyType="search"
              />
              {search.length > 0 && (
                <TouchableOpacity onPress={() => { setSearch(''); setShowAuto(false); }}>
                  <Ionicons name="close-circle" size={18} color="rgba(255,255,255,0.45)" />
                </TouchableOpacity>
              )}
            </View>
            {showAuto && (
              <AutocompleteDropdown results={autocomplete} onSelect={handleAutoSelect} />
            )}
          </FadeIn>
        </View>

        {/* ── Body ── */}
        <View style={styles.body}>

          {/* Ad Banner */}
          {ads.length > 0 && (
            <FadeIn delay={60}>
              <AdBanner ad={ads[0]} />
            </FadeIn>
          )}

          {/* Browse by Category */}
          <FadeIn delay={140}>
            <SectionHeader title="Browse by Category" />
            <View style={styles.catGrid}>
              {categories.map((item) => (
                <CategoryCard
                  key={item.key}
                  item={item}
                  onPress={() => navigation.navigate(item.route)}
                />
              ))}
            </View>
          </FadeIn>

          {/* People You May Know */}
          <FadeIn delay={220}>
            <SectionHeader
              title="People You May Know"
              onSeeAll={() => navigation.navigate('FeaturedPeople')}
            />
            {loading ? (
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 12, paddingBottom: 4 }}>
                {[1, 2, 3].map((i) => (
                  <View key={i} style={[styles.personCard, { alignItems: 'center', gap: 8 }]}>
                    <Skeleton width={64} height={64} radius={32} />
                    <Skeleton width={80} height={12} radius={6} />
                    <Skeleton width={60} height={10} radius={5} />
                    <Skeleton width={100} height={30} radius={100} style={{ marginTop: 4 }} />
                  </View>
                ))}
              </ScrollView>
            ) : featuredUsers.length > 0 ? (
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 12, paddingBottom: 4 }}>
                {featuredUsers.map((p) => <PersonCard key={p.id} person={p} />)}
              </ScrollView>
            ) : null}
          </FadeIn>

          {/* Trending Groups */}
          <FadeIn delay={300}>
            <SectionHeader
              title="Trending Groups"
              onSeeAll={() => navigation.navigate('Communities')}
            />
            {loading ? (
              <View style={{ gap: 14 }}>
                {[1, 2].map((i) => (
                  <View key={i} style={[styles.trendCard, { padding: 16, gap: 12 }]}>
                    <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
                      <Skeleton width={56} height={56} radius={16} />
                      <View style={{ gap: 8 }}>
                        <Skeleton width={140} height={14} radius={7} />
                        <Skeleton width={90}  height={11} radius={5} />
                      </View>
                    </View>
                    <Skeleton width="100%" height={90} radius={16} />
                  </View>
                ))}
              </View>
            ) : trendingGroups.length > 0 ? (
              <View style={styles.trendingList}>
                {trendingGroups.map((g) => (
                  <TrendingCard
                    key={g.id}
                    group={g}
                    onJoin={(group) => navigation.navigate('GroupDetails', { groupId: group.id })}
                  />
                ))}
              </View>
            ) : null}
          </FadeIn>

          {/* Guides & Articles */}
          <FadeIn delay={380}>
            <SectionHeader
              title="Guides & Tips"
              onSeeAll={() => navigation.navigate('Guides')}
            />
            {loading ? (
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 12, paddingBottom: 4 }}>
                {[1, 2, 3].map((i) => (
                  <View key={i} style={[styles.articleCard, { overflow: 'hidden' }]}>
                    <Skeleton width={200} height={110} radius={0} />
                    <View style={{ padding: 12, gap: 8 }}>
                      <Skeleton width={160} height={13} radius={6} />
                      <Skeleton width={100} height={10} radius={5} />
                    </View>
                  </View>
                ))}
              </ScrollView>
            ) : articles.length > 0 ? (
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 12, paddingBottom: 4 }}>
                {articles.map((a) => (
                  <ArticleCard
                    key={a.id}
                    article={a}
                    onPress={() => navigation.navigate('ArticleDetail', { articleId: a.id })}
                  />
                ))}
              </ScrollView>
            ) : null}
          </FadeIn>

          <View style={{ height: 110 }} />
        </View>
      </Animated.ScrollView>
    </View>
  );
};

// ─── Styles ───────────────────────────────────────────────────────────────────
const CARD_W = (SCREEN_W - 14 * 3) / 2;

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: CREAM },

  // Sticky header
  stickyHeader: {
    position: 'absolute', top: 0, left: 0, right: 0, zIndex: 20,
    backgroundColor: BRAND, paddingHorizontal: 20, paddingBottom: 12,
  },
  stickyTitle: {
    fontSize: 13, fontWeight: '700', color: '#fff', letterSpacing: 1.5,
    fontFamily: AppDetails?.fontFamily?.redex?.bold ?? 'System',
  },

  // Hero
  hero: { backgroundColor: BRAND, paddingHorizontal: 20, paddingBottom: 44, overflow: 'hidden' },
  blob1: { position: 'absolute', width: 230, height: 230, borderRadius: 115, backgroundColor: 'rgba(19,194,150,0.10)', top: 10,   right: -55 },
  blob2: { position: 'absolute', width: 170, height: 170, borderRadius: 85,  backgroundColor: 'rgba(19,194,150,0.07)', bottom: -40, left: -30 },
  blob3: { position: 'absolute', width: 100, height: 100, borderRadius: 50,  backgroundColor: 'rgba(255,255,255,0.04)', top: 60, left: SCREEN_W * 0.38 },

  heroEyebrow: {
    fontSize: 10, fontWeight: '800', letterSpacing: 3.5, color: ACCENT, marginBottom: 10,
    fontFamily: AppDetails?.fontFamily?.redex?.bold ?? 'System',
  },
  heroHeadline: {
    fontSize: 34, fontWeight: '900', color: '#fff', lineHeight: 42,
    fontFamily: AppDetails?.fontFamily?.redex?.bold ?? 'System',
  },

  // Search
  searchBar: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.13)',
    borderRadius: 16, borderWidth: 1, borderColor: 'rgba(255,255,255,0.2)',
    paddingHorizontal: 16, height: 50,
  },
  searchInput: {
    flex: 1, fontSize: 14, color: '#fff',
    fontFamily: AppDetails?.fontFamily?.inter?.regular ?? 'System',
  },

  // Autocomplete
  autocompleteWrap: {
    position: 'absolute', top: 54, left: 0, right: 0,
    backgroundColor: '#fff', borderRadius: 14, overflow: 'hidden',
    shadowColor: '#000', shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.14, shadowRadius: 16, elevation: 12, zIndex: 100,
  },
  autocompleteItem:   { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 13 },
  autocompleteDivider:{ borderBottomWidth: 1, borderBottomColor: 'rgba(12,63,68,0.07)' },
  autocompleteText:   { fontSize: 13, color: DARK, flex: 1, fontFamily: AppDetails?.fontFamily?.inter?.regular ?? 'System' },

  // Body
  body: {
    backgroundColor: CREAM, borderTopLeftRadius: 28, borderTopRightRadius: 28,
    marginTop: -22, paddingTop: 26, paddingHorizontal: 14,
  },

  // Ad
  adBanner: { borderRadius: 18, overflow: 'hidden', marginBottom: 22, height: 88, backgroundColor: `${BRAND}14` },
  adOverlay: {
    ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(12,63,68,0.45)',
    flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, gap: 10,
  },
  adPill:     { backgroundColor: ACCENT, borderRadius: 6, paddingHorizontal: 7, paddingVertical: 3 },
  adPillText: { fontSize: 9, fontWeight: '800', color: '#fff', letterSpacing: 0.5 },
  adTitle:    { fontSize: 14, fontWeight: '700', color: '#fff', flex: 1, fontFamily: AppDetails?.fontFamily?.redex?.bold ?? 'System' },

  // Section header
  sectionHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14, marginTop: 6 },
  sectionTitle:  { fontSize: 20, fontWeight: '800', color: DARK, fontFamily: AppDetails?.fontFamily?.redex?.bold ?? 'System' },
  seeAll:        { fontSize: 13, fontWeight: '700', color: ACCENT, fontFamily: AppDetails?.fontFamily?.redex?.bold ?? 'System' },

  // Category grid
  catGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 14, marginBottom: 30 },
  catCard: {
    width: CARD_W, height: CARD_W * 0.88,
    borderRadius: 22, padding: 18, justifyContent: 'flex-end', overflow: 'hidden',
  },
  catCircle: {
    position: 'absolute',
    width: CARD_W * 0.68, height: CARD_W * 0.68, borderRadius: CARD_W * 0.34,
    bottom: -CARD_W * 0.22, right: -CARD_W * 0.16, opacity: 0.42,
  },
  catEmoji: { fontSize: 30, marginBottom: 8 },
  catLabel: { fontSize: 17, fontWeight: '800', color: '#fff', fontFamily: AppDetails?.fontFamily?.redex?.bold ?? 'System' },
  catSub:   { fontSize: 11, color: 'rgba(255,255,255,0.68)', marginTop: 3, fontFamily: AppDetails?.fontFamily?.inter?.regular ?? 'System' },

  // Person card
  personCard: {
    width: 140, backgroundColor: '#fff', borderRadius: 20, padding: 16, alignItems: 'center',
    borderWidth: 1, borderColor: 'rgba(12,63,68,0.07)',
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.05, shadowRadius: 8, elevation: 2,
    marginBottom: 4,
  },
  personAvatar:         { width: 64, height: 64, borderRadius: 32, borderWidth: 2, borderColor: ACCENT, marginBottom: 10 },
  personAvatarFallback: { backgroundColor: `${ACCENT}22`, alignItems: 'center', justifyContent: 'center' },
  personName:  { fontSize: 13, fontWeight: '700', color: DARK, textAlign: 'center', fontFamily: AppDetails?.fontFamily?.redex?.bold ?? 'System' },
  personCity:  { fontSize: 11, color: MUTED, marginTop: 3, marginBottom: 12 },
  verifiedBadge: {
    position: 'absolute', top: 8, right: 8,
    width: 18, height: 18, borderRadius: 9,
    backgroundColor: ACCENT, alignItems: 'center', justifyContent: 'center',
  },
  connectBtn:  { borderWidth: 1.5, borderColor: BRAND, borderRadius: 100, paddingHorizontal: 16, paddingVertical: 6, width: '100%', alignItems: 'center', marginTop: 10 },
  connectBtnText: { fontSize: 12, fontWeight: '700', color: BRAND, fontFamily: AppDetails?.fontFamily?.redex?.bold ?? 'System' },

  // Trending card
  trendingList: { gap: 16, marginBottom: 30 },
  trendCard: {
    backgroundColor: '#fff', borderRadius: 22, overflow: 'hidden',
    borderWidth: 1, borderColor: 'rgba(12,63,68,0.07)',
    shadowColor: '#000', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.06, shadowRadius: 10, elevation: 3,
  },
  trendHeader:        { flexDirection: 'row', alignItems: 'center', gap: 14, padding: 16 },
  trendAvatar:        { width: 56, height: 56, borderRadius: 16 },
  trendAvatarFallback:{ backgroundColor: `${BRAND}15`, alignItems: 'center', justifyContent: 'center' },
  trendName:          { fontSize: 16, fontWeight: '800', color: DARK, fontFamily: AppDetails?.fontFamily?.redex?.bold ?? 'System' },
  trendMeta:          { fontSize: 12, color: MUTED, marginTop: 3, fontFamily: AppDetails?.fontFamily?.inter?.regular ?? 'System' },
  trendExpanded:      { backgroundColor: BRAND, borderRadius: 18, margin: 10, marginTop: 0, padding: 18 },
  trendLocation:      { fontSize: 16, fontWeight: '800', color: '#fff', marginBottom: 8, fontFamily: AppDetails?.fontFamily?.redex?.bold ?? 'System' },
  trendAbout:         { fontSize: 13, color: 'rgba(255,255,255,0.72)', lineHeight: 19, marginBottom: 18, fontFamily: AppDetails?.fontFamily?.inter?.regular ?? 'System' },
  trendStats:         { flexDirection: 'row', gap: 28, marginBottom: 18 },
  trendStat:          {},
  trendStatNum:       { fontSize: 22, fontWeight: '900', color: ACCENT, fontFamily: AppDetails?.fontFamily?.redex?.bold ?? 'System' },
  trendStatLabel:     { fontSize: 11, color: 'rgba(255,255,255,0.55)', marginTop: 2, fontFamily: AppDetails?.fontFamily?.inter?.regular ?? 'System' },
  joinBtn:            { backgroundColor: 'rgba(255,255,255,0.14)', borderWidth: 1.5, borderColor: 'rgba(255,255,255,0.28)', borderRadius: 100, paddingVertical: 13, alignItems: 'center' },
  joinBtnText:        { fontSize: 14, fontWeight: '800', color: '#fff', fontFamily: AppDetails?.fontFamily?.redex?.bold ?? 'System' },

  // Article card
  articleCard: {
    width: 200, backgroundColor: '#fff', borderRadius: 18, overflow: 'hidden',
    borderWidth: 1, borderColor: 'rgba(12,63,68,0.07)',
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.05, shadowRadius: 8, elevation: 2,
    marginBottom: 4,
  },
  articleImg:        { width: '100%', height: 110 },
  articleImgFallback:{ backgroundColor: `${BRAND}12`, alignItems: 'center', justifyContent: 'center' },
  articleBody:       { padding: 12 },
  articleTag:        { alignSelf: 'flex-start', backgroundColor: `${ACCENT}18`, borderRadius: 6, paddingHorizontal: 7, paddingVertical: 2, marginBottom: 5 },
  articleTagText:    { fontSize: 9, fontWeight: '700', color: '#0a7a5a', letterSpacing: 0.3, fontFamily: AppDetails?.fontFamily?.inter?.regular ?? 'System' },
  articleTitle:      { fontSize: 13, fontWeight: '700', color: DARK, lineHeight: 18, fontFamily: AppDetails?.fontFamily?.redex?.bold ?? 'System' },
  articleMeta:       { fontSize: 10, color: MUTED, marginTop: 5, fontFamily: AppDetails?.fontFamily?.inter?.regular ?? 'System' },
});

export default DiscoveryScreen;